 package bt2;
 public abstract class Hinh {
    public abstract double tinhDienTich();
}