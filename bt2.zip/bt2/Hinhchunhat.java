package bt2;

public class HinhChuNhat extends Hinh {
    private int chieuDai, chieuRong;
     
    public HinhChuNhat() {
        super();
    }
 
    public HinhChuNhat(int chieuDai, int chieuRong) {
        super();
        this.chieuDai = chieuDai;
        this.chieuRong = chieuRong;
    }

    public double tinhDienTich() {
        return chieuDai * chieuRong;
    }
 
    public String toString() {
        return "Hình chữ nhật có chiều dài = " + this.chieuDai + 
            ", chiều rộng = " + this.chieuRong + ", diện tích = " + tinhDienTich();
    }
}