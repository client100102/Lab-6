package bt2;

import java.text.DecimalFormat;

public class HinhTron extends Hinh {
    private int banKinh;
    DecimalFormat dcf = new DecimalFormat("#.##");
 
    public HinhTron() {
        super();
    }
 
    public HinhTron(int banKinh) {
        super();
        this.banKinh = banKinh;
    }

    public double tinhDienTich() {
        return 3.14 * banKinh * banKinh;
    }
    
    public String toString() {
        return "Hình tròn có bán kính = " + this.banKinh + 
            ", diện tích = " + dcf.format(tinhDienTich());
    }
}
 