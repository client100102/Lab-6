package bt2;

import java.util.ArrayList;

public class DanhSachHinh {
    ArrayList<Hinh> arrHinh;
 
    public DanhSachHinh() {
        super();
        arrHinh = new ArrayList<>();
        arrHinh.add(new HinhChuNhat(7, 3));
        arrHinh.add(new HinhTron(3));
        arrHinh.add(new HinhChuNhat(10, 1));
    }
     
    public void themHinh(Hinh hinh) {
        arrHinh.add(hinh);
    }
     
    public void hienThiDanhSachHinh() {
        for (int i = 0; i < arrHinh.size(); i++) {
            System.out.println(arrHinh.get(i).toString());
        }
    }
     
    public int demSoHinhChuNhat() {
        int soHinhChuNhat = 0;
        for (Hinh hinh : arrHinh) {
            if (hinh instanceof HinhChuNhat) {
                soHinhChuNhat++;
            }
        }
        return soHinhChuNhat;
    }
     
    public void hienThiHinhChuNhatCoDienTichLonNhat() {
        double temp = 0;
        HinhChuNhat hinhChuNhat = new HinhChuNhat();
        for (Hinh hinh : arrHinh) {
            if (hinh instanceof HinhChuNhat) {
                if (temp < hinh.tinhDienTich()) {
                    temp = hinh.tinhDienTich();
                    hinhChuNhat = (HinhChuNhat) hinh;
                }
            }
        }
        System.out.println("Hình chữ nhật có diện tích lớn nhất là " + hinhChuNhat.toString());
    }
}